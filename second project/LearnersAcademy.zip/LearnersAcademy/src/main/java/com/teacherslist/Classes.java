package com.teacherslist;

import com.teacherslist.Student;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class Classes {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="cid")
	private int id;
	private String name;
	@OneToOne
	private Student student;
	

	public Classes() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setClassName(String Name) {
		name = Name;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	
	public Classes(String Name, Student student) {
		super();
		name = Name;
		this.student = student;
	}
	@Override
	public String toString() {
		return "Classes [id=" + id + ", Name=" + name + ", student=" + student + "]";
	}

	
}